RETAIL SUPERMARKET INVENTORY DATASET
=====================================

This folder contains small, consistent CSV datasets for the inventory management assignment.
The sample records are prepared to match the assignment's table relationships; they are not
downloaded from Mockaroo. You can use these files directly for testing or reproduce similar
fields in Mockaroo.

CSV files:
- categories.csv (10)
- products.csv (30)
- suppliers.csv (3)
- warehouses.csv (2)
- branches.csv (2)
- employees.csv (5)
- inventory.csv (60; each product appears once at each branch)
- purchase_orders.csv (5)
- purchase_order_lines.csv (10)
- sales_transactions.csv (10)
- sales_transaction_lines.csv (20)

Suggested import order:
1. categories.csv
2. suppliers.csv
3. warehouses.csv
4. branches.csv
5. products.csv
6. employees.csv
7. inventory.csv
8. purchase_orders.csv
9. purchase_order_lines.csv
10. sales_transactions.csv
11. sales_transaction_lines.csv

Important:
- Create tables in schema.sql before importing data.
- Ensure table column names/types match the CSV headers.
- IDs are included in the CSV files; if using GENERATED ALWAYS AS IDENTITY, use an import
  approach that allows explicit IDs or remove identity restrictions for seed loading.
- Sales include dates within the seven-day reporting window (as of 2026-10-19).
- Some products are intentionally never sold, so query 6 returns results.
- Inventory includes several low-stock rows, so query 2 returns results.
- If you add the stock-reduction trigger, load inventory before sales and avoid importing
  the sales lines twice.
